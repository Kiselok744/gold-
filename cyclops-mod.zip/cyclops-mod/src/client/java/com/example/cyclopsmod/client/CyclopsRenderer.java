package com.example.cyclopsmod.client;

import com.example.cyclopsmod.CyclopsBoss;
import com.example.cyclopsmod.CyclopsMod;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.state.HumanoidRenderState;
import net.minecraft.resources.Identifier;

/**
 * Рендер: берём ванильную модель гуманоида (как у зомби), увеличиваем в 3 раза и накладываем свою текстуру с одним глазом.
 * Когда босс сидит - включаем "пассажирскую" позу (ноги вперёд), как у сидящего в лодке.
 */
public class CyclopsRenderer extends HumanoidMobRenderer<CyclopsBoss, HumanoidRenderState, HumanoidModel<HumanoidRenderState>> {
    private static final Identifier TEXTURE =
        Identifier.fromNamespaceAndPath(CyclopsMod.MOD_ID, "textures/entity/cyclops.png");
    private static final float SCALE = 3.0f;

    public CyclopsRenderer(EntityRendererProvider.Context context) {
        super(context, new HumanoidModel<>(context.bakeLayer(ModelLayers.ZOMBIE)), 0.5f * SCALE);
    }

    @Override
    public HumanoidRenderState createRenderState() {
        return new HumanoidRenderState();
    }

    @Override
    public void extractRenderState(CyclopsBoss entity, HumanoidRenderState state, float partialTick) {
        super.extractRenderState(entity, state, partialTick);
        // Рендер не видит саму сущность, только "состояние", которое мы тут заполняем
        state.isPassenger = entity.getState() == CyclopsBoss.SITTING;
    }

    @Override
    protected void scale(HumanoidRenderState state, PoseStack poseStack) {
        poseStack.scale(SCALE, SCALE, SCALE);
    }

    @Override
    public Identifier getTextureLocation(HumanoidRenderState state) {
        return TEXTURE;
    }
}
