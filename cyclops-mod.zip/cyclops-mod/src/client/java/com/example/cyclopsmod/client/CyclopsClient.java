package com.example.cyclopsmod.client;

import com.example.cyclopsmod.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;

/** Клиентская точка входа: тут регистрируем рендерер. Sodium не мешает - мы используем только стандартные API рендера. */
public class CyclopsClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(ModEntities.CYCLOPS, CyclopsRenderer::new);
    }
}
