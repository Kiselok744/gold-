package com.example.cyclopsmod;

import java.util.HashSet;
import java.util.Random;
import java.util.Set;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.Heightmap;

/**
 * Естественная генерация подземелий.
 * Мир делится на клетки 640x640 блоков. Для каждой клетки по сиду мира детерминированно решается:
 * есть ли в ней подземелье (60%) и где (случайная точка). Когда игрок подходит ближе 96 блоков и все нужные
 * чанки загружены, подземелье строится на глубине ~30 блоков под поверхностью, с шахтой и лестницей наверх.
 * Так мы не лезем в процесс генерации чанков (это сложнее и хрупче), а строим уже готовый мир.
 */
public final class DungeonSpawner {
    private static final int CELL = 640;
    private static final int MIN_DIST_FROM_ORIGIN = 150; // не рядом со стартовой точкой
    private static final int ACTIVATE_DIST = 96;
    private static final int DEPTH_BELOW_SURFACE = 30;
    // Уже обработанные участки за эту сессию (чтобы не проверять маркер каждые 5 секунд). Ключ содержит сид мира.
    private static final Set<String> handled = new HashSet<>();

    private DungeonSpawner() {}

    public static void init() {
        // Событие конца тика сервера; подземелья строим только в обычном мире (Overworld)
        ServerTickEvents.END_SERVER_TICK.register(server -> tick(server.overworld()));
    }

    private static void tick(ServerLevel level) {
        if (level.dimension() != Level.OVERWORLD || level.getGameTime() % 100 != 0) return;
        for (ServerPlayer player : level.players()) {
            int pcx = Math.floorDiv(player.getBlockX(), CELL);
            int pcz = Math.floorDiv(player.getBlockZ(), CELL);
            for (int dx = -1; dx <= 1; dx++)
                for (int dz = -1; dz <= 1; dz++)
                    trySite(level, player, pcx + dx, pcz + dz);
        }
    }

    private static void trySite(ServerLevel level, ServerPlayer player, int cx, int cz) {
        long seed = level.getSeed();
        String key = seed + ":" + cx + ":" + cz;
        if (handled.contains(key)) return;

        // Решение по клетке зависит только от сида и координат клетки - всегда одинаковое для этого мира
        Random r = new Random(seed ^ (cx * 341873128712L) ^ (cz * 132897987541L) ^ 0x5DEECE66DL);
        if (r.nextInt(100) >= 60) { handled.add(key); return; }
        int sx = cx * CELL + 40 + r.nextInt(CELL - 80);
        int sz = cz * CELL + 40 + r.nextInt(CELL - 80);
        if (Math.abs(sx) < MIN_DIST_FROM_ORIGIN && Math.abs(sz) < MIN_DIST_FROM_ORIGIN) { handled.add(key); return; }

        double ddx = sx - player.getX(), ddz = sz - player.getZ();
        if (ddx * ddx + ddz * ddz > ACTIVATE_DIST * ACTIVATE_DIST) return;

        // Весь участок (вместе с шахтой и залом) должен быть в загруженных чанках, иначе подождём
        if (!level.hasChunksAt(new BlockPos(sx - 14, 0, sz - 10), new BlockPos(sx + 14, 0, sz + 38))) return;

        int surface = level.getHeight(Heightmap.Types.WORLD_SURFACE_WG, sx, sz);
        int oceanFloor = level.getHeight(Heightmap.Types.OCEAN_FLOOR_WG, sx, sz);
        if (surface > oceanFloor) { handled.add(key); return; } // под водой не строим

        int oy = Math.max(surface - DEPTH_BELOW_SURFACE, level.getMinY() + 6);
        BlockPos origin = new BlockPos(sx, oy, sz);

        BlockPos marker = origin.offset(CyclopsDungeon.MARKER_OFFSET);
        if (!level.getBlockState(marker).is(Blocks.REINFORCED_DEEPSLATE)) {
            CyclopsDungeon.build(level, origin, surface - oy);
        }
        handled.add(key);
    }
}
