package com.example.cyclopsmod;

import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;

/** Регистрация сущностей. Всё, что есть в игре (блок, предмет, моб), должно быть зарегистрировано в реестре. */
public class ModEntities {
    public static final ResourceKey<EntityType<?>> CYCLOPS_KEY =
        ResourceKey.create(Registries.ENTITY_TYPE, Identifier.fromNamespaceAndPath(CyclopsMod.MOD_ID, "cyclops"));

    // Размер хитбокса = зомби (0.6 x 1.95) * 3, потому что рендерим модель в 3 раза больше
    public static final EntityType<CyclopsBoss> CYCLOPS = Registry.register(
        BuiltInRegistries.ENTITY_TYPE, CYCLOPS_KEY,
        EntityType.Builder.of(CyclopsBoss::new, MobCategory.MONSTER)
            .sized(1.8f, 5.85f)
            .clientTrackingRange(12)
            .build(CYCLOPS_KEY));

    public static void init() {
        // Атрибуты (здоровье, урон...) тоже надо зарегистрировать
        FabricDefaultAttributeRegistry.register(CYCLOPS, CyclopsBoss.createAttributes());
    }
}
