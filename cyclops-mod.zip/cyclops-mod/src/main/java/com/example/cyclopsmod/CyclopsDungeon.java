package com.example.cyclopsmod;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LadderBlock;
import net.minecraft.world.level.block.StairBlock;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Генератор подземелья кодом. Система координат: o = точка у входа (на уровне ног игрока),
 * зал тянется в сторону +Z (юг). Трон стоит в дальнем конце (z ~ 31), босс смотрит на вход.
 */
public final class CyclopsDungeon {
    private static final int HALF_W = 12;   // зал шириной 25
    private static final int DEPTH = 36;    // длина зала
    private static final int HEIGHT = 16;   // высота потолка

    private static final BlockState WALL = Blocks.POLISHED_BLACKSTONE_BRICKS.defaultBlockState();
    private static final BlockState AIR = Blocks.AIR.defaultBlockState();
    private static final BlockState FLOOR_A = Blocks.DEEPSLATE_TILES.defaultBlockState();
    private static final BlockState FLOOR_B = Blocks.POLISHED_DEEPSLATE.defaultBlockState();
    private static final BlockState PILLAR = Blocks.CHISELED_POLISHED_BLACKSTONE.defaultBlockState();
    private static final BlockState GOLD = Blocks.GOLD_BLOCK.defaultBlockState();
    private static final BlockState GILDED = Blocks.GILDED_BLACKSTONE.defaultBlockState();
    private static final BlockState LANTERN = Blocks.SOUL_LANTERN.defaultBlockState();
    private static final BlockState STAIRS_S = Blocks.POLISHED_BLACKSTONE_BRICK_STAIRS.defaultBlockState()
        .setValue(StairBlock.FACING, Direction.SOUTH); // подъём в сторону +Z

    /** Смещение скрытого маркера (армированный глубинный сланец под полом): по нему узнаём, что подземелье тут уже построено. */
    public static final BlockPos MARKER_OFFSET = new BlockPos(0, -2, 10);

    /** Вариант для команды: подземелье на поверхности, без шахты. */
    public static void build(ServerLevel level, BlockPos o) {
        build(level, o, 0);
    }

    /** shaftTop > 0 - подземелье под землёй, а до поверхности (на высоте shaftTop над o) ведёт шахта с лестницей. */
    public static void build(ServerLevel level, BlockPos o, int shaftTop) {
        // 1. Сплошная "коробка" стен, потом выдалбливаем внутри
        fill(level, o, -HALF_W - 1, -1, -6, HALF_W + 1, HEIGHT + 1, DEPTH + 1, WALL);
        if (shaftTop > 0) fill(level, o, -2, -1, -9, 2, shaftTop, -5, WALL); // стенки шахты
        fill(level, o, -HALF_W, 0, 1, HALF_W, HEIGHT, DEPTH, AIR);     // зал
        fill(level, o, -2, 0, -6, 2, 4, 0, AIR);                       // коридор-вход
        if (shaftTop > 0) buildShaft(level, o, shaftTop);
        set(level, o, MARKER_OFFSET.getX(), MARKER_OFFSET.getY(), MARKER_OFFSET.getZ(),
            Blocks.REINFORCED_DEEPSLATE.defaultBlockState());

        // 2. Пол в шахматку
        for (int x = -HALF_W; x <= HALF_W; x++)
            for (int z = 1; z <= DEPTH; z++)
                set(level, o, x, -1, z, ((x + z) & 1) == 0 ? FLOOR_A : FLOOR_B);

        // 3. Колонны с лампами
        for (int x : new int[]{-8, 8})
            for (int z : new int[]{6, 14, 22}) {
                fill(level, o, x, 0, z, x, 8, z, PILLAR);
                set(level, o, x, 9, z, LANTERN);
            }

        // 4. Лампы вдоль стен, чтобы внутри не спавнились обычные мобы
        for (int z = 4; z <= DEPTH - 2; z += 6) {
            set(level, o, -HALF_W, 0, z, LANTERN);
            set(level, o, HALF_W, 0, z, LANTERN);
        }

        // 5. Подиум: два уровня + лестницы
        fill(level, o, -8, 0, 24, 8, 0, DEPTH, WALL);
        fill(level, o, -8, 0, 23, 8, 0, 23, STAIRS_S);
        fill(level, o, -6, 1, 27, 6, 1, DEPTH, WALL);
        fill(level, o, -6, 1, 26, 6, 1, 26, STAIRS_S);
        fill(level, o, -6, 1, 27, 6, 1, 27, GILDED);

        // 6. Трон: платформа, высокая спинка, подлокотники
        fill(level, o, -2, 2, 28, 2, 2, 33, GOLD);                     // сиденье (верх на y=3)
        fill(level, o, -2, 3, 34, 2, 12, DEPTH, WALL);                 // спинка
        fill(level, o, -1, 13, 34, 1, 14, DEPTH, WALL);                // навершие
        fill(level, o, -3, 3, 28, -3, 4, 33, WALL);                    // подлокотники
        fill(level, o, 3, 3, 28, 3, 4, 33, WALL);
        set(level, o, -3, 5, 28, LANTERN);
        set(level, o, 3, 5, 28, LANTERN);

        // 7. Босс на троне (по центру сиденья, лицом к входу = на север = yaw 180)
        CyclopsBoss boss = ModEntities.CYCLOPS.create(level, EntitySpawnReason.COMMAND);
        if (boss != null) {
            boss.snapTo(o.getX() + 0.5, o.getY() + 3, o.getZ() + 31.5, 180.0f, 0.0f);
            level.addFreshEntity(boss);
        }
    }

    /** Вертикальная шахта 3x3 от коридора до поверхности: лестница на северной стене + 4 колонны-метки наверху. */
    private static void buildShaft(ServerLevel level, BlockPos o, int top) {
        fill(level, o, -1, 0, -8, 1, top, -6, AIR);
        BlockState ladder = Blocks.LADDER.defaultBlockState().setValue(LadderBlock.FACING, Direction.SOUTH);
        for (int y = 0; y <= top; y++) set(level, o, 0, y, -8, ladder);
        for (int x : new int[]{-2, 2})
            for (int z : new int[]{-9, -5})
                fill(level, o, x, top, z, x, top + 3, z, PILLAR);
    }

    private static void set(ServerLevel level, BlockPos o, int x, int y, int z, BlockState state) {
        level.setBlock(o.offset(x, y, z), state, 3);
    }

    private static void fill(ServerLevel level, BlockPos o, int x1, int y1, int z1, int x2, int y2, int z2, BlockState state) {
        for (int x = x1; x <= x2; x++)
            for (int y = y1; y <= y2; y++)
                for (int z = z1; z <= z2; z++)
                    set(level, o, x, y, z, state);
    }
}
