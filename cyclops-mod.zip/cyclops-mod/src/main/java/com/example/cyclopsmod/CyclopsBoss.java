package com.example.cyclopsmod;

import java.util.UUID;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;

/**
 * Король-Циклоп.
 * Три состояния:
 *  SITTING  - сидит на троне, отключён ИИ, неуязвим
 *  RISING   - игрок подошёл, босс встаёт (2.5 секунды), всё ещё неуязвим
 *  FIGHTING - обычный бой + удар по земле раз в несколько секунд
 */
public class CyclopsBoss extends Monster {
    public static final int SITTING = 0, RISING = 1, FIGHTING = 2;
    private static final int WAKE_RADIUS = 14;
    private static final int RISE_TICKS = 50;

    // SynchedEntityData - данные, которые сервер автоматически шлёт клиенту (нужно, чтобы рендер знал, сидит босс или нет)
    private static final EntityDataAccessor<Integer> STATE =
        SynchedEntityData.defineId(CyclopsBoss.class, EntityDataSerializers.INT);

    private final ServerBossEvent bossEvent = new ServerBossEvent(
        UUID.randomUUID(),
        Component.translatable("entity.cyclops_mod.cyclops"),
        BossEvent.BossBarColor.RED, BossEvent.BossBarOverlay.NOTCHED_10);

    private int riseTicks = 0;
    private int slamCooldown = 100;

    public CyclopsBoss(EntityType<? extends CyclopsBoss> type, Level level) {
        super(type, level);
        this.xpReward = 200;
        this.setPersistenceRequired(); // не деспавнится
        this.setNoAi(true);            // пока сидит - не двигается
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
            .add(Attributes.MAX_HEALTH, 300.0)
            .add(Attributes.ATTACK_DAMAGE, 14.0)
            .add(Attributes.MOVEMENT_SPEED, 0.28)
            .add(Attributes.KNOCKBACK_RESISTANCE, 1.0)
            .add(Attributes.ARMOR, 8.0)
            .add(Attributes.FOLLOW_RANGE, 40.0);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(STATE, SITTING);
    }

    public int getState() { return this.entityData.get(STATE); }
    private void setState(int s) { this.entityData.set(STATE, s); }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(1, new FloatGoal(this));
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.0, true));
        this.goalSelector.addGoal(3, new WaterAvoidingRandomStrollGoal(this, 0.8));
        this.goalSelector.addGoal(4, new LookAtPlayerGoal(this, Player.class, 16.0f));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override
    public void tick() {
        super.tick();
        if (!(this.level() instanceof ServerLevel level)) return;

        bossEvent.setProgress(this.getHealth() / this.getMaxHealth());

        switch (getState()) {
            case SITTING -> {
                Player p = level.getNearestPlayer(this, WAKE_RADIUS);
                if (p != null && !p.isSpectator()) {
                    setState(RISING);
                    riseTicks = 0;
                    this.playSound(SoundEvents.RAVAGER_ROAR, 3.0f, 0.5f);
                }
            }
            case RISING -> {
                riseTicks++;
                // тряска и пыль, пока встаёт
                if (riseTicks % 5 == 0) {
                    level.sendParticles(ParticleTypes.CAMPFIRE_COSY_SMOKE,
                        getX(), getY() + 0.2, getZ(), 12, 1.5, 0.1, 1.5, 0.02);
                    this.playSound(SoundEvents.IRON_GOLEM_DAMAGE, 2.0f, 0.5f);
                }
                if (riseTicks >= RISE_TICKS) {
                    setState(FIGHTING);
                    this.setNoAi(false);
                    Player p = level.getNearestPlayer(this, 40);
                    if (p != null) this.setTarget(p);
                }
            }
            case FIGHTING -> {
                if (slamCooldown > 0) slamCooldown--;
                var target = this.getTarget();
                if (slamCooldown <= 0 && target != null && this.distanceToSqr(target) < 64) {
                    groundSlam(level);
                    // во второй фазе (меньше половины HP) бьёт чаще
                    slamCooldown = this.getHealth() < this.getMaxHealth() / 2 ? 70 : 120;
                }
            }
            default -> {}
        }
    }

    /** Удар по земле: урон и подброс всем игрокам в радиусе 6 блоков. */
    private void groundSlam(ServerLevel level) {
        this.playSound(SoundEvents.RAVAGER_ROAR, 2.0f, 0.7f);
        level.sendParticles(ParticleTypes.EXPLOSION_EMITTER, getX(), getY() + 0.5, getZ(), 1, 0, 0, 0, 0);
        for (Player p : level.getEntitiesOfClass(Player.class, this.getBoundingBox().inflate(6.0, 2.0, 6.0))) {
            p.hurtServer(level, this.damageSources().mobAttack(this), 12.0f);
            double dx = p.getX() - getX(), dz = p.getZ() - getZ();
            double len = Math.max(0.1, Math.sqrt(dx * dx + dz * dz));
            // Скорость синхронизируется с клиентом автоматически: hurtServer() выше уже пометил игрока как "получившего удар"
            p.setDeltaMovement(dx / len * 1.2, 0.9, dz / len * 1.2);
        }
    }

    /** Пока босс сидит или встаёт - урон не проходит. */
    @Override
    public boolean hurtServer(ServerLevel level, DamageSource source, float amount) {
        if (getState() != FIGHTING) return false;
        return super.hurtServer(level, source, amount);
    }

    @Override
    public boolean removeWhenFarAway(double distance) { return false; }

    // --- Боссбар: показываем только тем игрокам, которые "видят" босса ---
    @Override
    public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player);
        bossEvent.addPlayer(player);
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player);
        bossEvent.removePlayer(player);
    }

    // --- Сохранение в мир ---
    @Override
    protected void addAdditionalSaveData(ValueOutput output) {
        super.addAdditionalSaveData(output);
        output.putInt("CyclopsState", getState());
    }

    @Override
    protected void readAdditionalSaveData(ValueInput input) {
        super.readAdditionalSaveData(input);
        int s = input.getIntOr("CyclopsState", SITTING);
        setState(s);
        this.setNoAi(s != FIGHTING);
    }
}
