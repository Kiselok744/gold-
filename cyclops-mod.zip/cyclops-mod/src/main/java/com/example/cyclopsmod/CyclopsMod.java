package com.example.cyclopsmod;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;

/** Главный класс мода: Fabric вызывает onInitialize() при старте (и на клиенте, и на сервере). */
public class CyclopsMod implements ModInitializer {
    public static final String MOD_ID = "cyclops_mod";

    @Override
    public void onInitialize() {
        ModEntities.init();
        DungeonSpawner.init(); // естественная генерация подземелий в мире

        // Команда /cyclops_dungeon строит подземелье перед игроком и сажает босса на трон.
        // TODO: добавить .requires(...) с проверкой прав оператора (API прав менялся в последних версиях)
        CommandRegistrationCallback.EVENT.register((dispatcher, buildContext, selection) ->
            dispatcher.register(Commands.literal("cyclops_dungeon").executes(ctx -> {
                CommandSourceStack src = ctx.getSource();
                ServerLevel level = src.getLevel();
                BlockPos origin = BlockPos.containing(src.getPosition());
                CyclopsDungeon.build(level, origin);
                src.sendSuccess(() -> Component.literal("Подземелье построено. Иди вперёд (на юг, +Z) и разбуди Циклопа."), true);
                return 1;
            })));
    }
}
